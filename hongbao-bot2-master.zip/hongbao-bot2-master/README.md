# 饿了么红包微信机器人
原项目[hongbao-bot](https://github.com/dj940212/hongbao-bot)已经失效，在本项目进行修复，仅支持饿了么

## 使用
- 向机器人微信转发饿了么拼手气红包
- 提示后填写手机号码即可领取最大红包

![](http://ovs5x36k4.bkt.clouddn.com/QQ20180227-0.png?imageView2/2/w/400)



## 运行

克隆

```
git clone https://github.com/dj940212/hongbao-bot2.git
```

安装依赖

```
npm install
```

执行

```
npm run start
```

使用微信扫码登录即可

## 说明

- 抢大红包原理是用qq小号点掉前面小红包，将大红包留给指定账号
- 抢大红包会消耗饿了么用户手机号和cookie，需要自行准备
- 运行程序有可能会被限制网页微信登录


